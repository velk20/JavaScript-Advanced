//reference types

function qqq(num) {
  if (typeof num == 'number') {
    return 'hi number';
  }
  return 'hi baby!';
}
let namee = qqq('saas');
console.log(namee);

let num = (a, b) => {
  sdasdasdd;
  rett;
};
num(2, 2);
